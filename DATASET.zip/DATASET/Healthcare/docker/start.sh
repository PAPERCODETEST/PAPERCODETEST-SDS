#!/usr/bin/env bash
set -xe
docker run -p 127.0.0.1:8888:8888 -d -t computationalhealthcare